######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Sat Sep 12 10:44:30 +07 2026

# This file contains the Genus script for design:picorv32

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path /home/icd1/workspace/RISC-V-PROCESSOR-45nm/lib
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 48 96 50 101} {first_condense 53 165 61 178} {PBS_Generic_Opt-Post 121 168 121.830163 170.662456} {{PBS_Generic-Postgen HBO Optimizations} 0 168 0.0 170.662456} {PBS_TechMap-Start 0 175 0.0 176.228583} {{PBS_TechMap-Premap HBO Optimizations} 0 175 0.0 176.228583} {first_condense 58 234 69 258} {reify 85 319 150 408} {global_incr_map 13 332 14 423} {{PBS_Techmap-Global Mapping} 157 332 154.10497399999988 330.33355699999987} {{PBS_TechMap-Datapath Postmap Operations} 6 338 5.858159000000001 336.1917159999999} {{PBS_TechMap-Postmap HBO Optimizations} 0 338 0.8656530000000089 337.0573689999999} {{PBS_TechMap-Postmap Clock Gating} 1 339 1.0 338.0573689999999} {{PBS_TechMap-Postmap Cleanup} 1 340 -0.13547399999998788 337.9218949999999} {PBS_Techmap-Post_MBCI 0 340 0.0 337.9218949999999} {incr_opt 16 359 17 451} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path {/home/icd1/workspace/RISC-V-PROCESSOR-45nm /home/icd1/workspace/RISC-V-PROCESSOR-45nm/synthesis}
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 1.0
set_db -quiet read_qrc_tech_file_rc_corner true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
