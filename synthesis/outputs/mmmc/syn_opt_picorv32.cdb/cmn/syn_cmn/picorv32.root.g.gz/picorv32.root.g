######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Sat Sep 12 11:05:51 +07 2026

# This file contains the Genus script for design:picorv32

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path /home/icd1/workspace/RISC-V-PROCESSOR-45nm/lib
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 50 96 52 103} {first_condense 54 165 62 182} {PBS_Generic_Opt-Post 122 168 123.902828 173.66397} {{PBS_Generic-Postgen HBO Optimizations} 1 169 0.0 173.66397} {PBS_TechMap-Start 0 176 0.0 179.153675} {{PBS_TechMap-Premap HBO Optimizations} 0 176 1.0 180.153675} {first_condense 59 235 72 265} {reify 89 324 159 424} {global_incr_map 15 339 16 441} {{PBS_Techmap-Global Mapping} 163 339 160.40031500000006 340.55399000000006} {{PBS_TechMap-Datapath Postmap Operations} 6 345 5.834406000000001 346.38839600000006} {{PBS_TechMap-Postmap HBO Optimizations} 0 345 0.8431619999999498 347.231558} {{PBS_TechMap-Postmap Clock Gating} 1 346 0.0 347.231558} {{PBS_TechMap-Postmap Cleanup} 0 346 0.8370249999999828 348.068583} {PBS_Techmap-Post_MBCI 0 346 0.0 348.068583} {incr_opt 17 366 18 469} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path {/home/icd1/workspace/RISC-V-PROCESSOR-45nm /home/icd1/workspace/RISC-V-PROCESSOR-45nm/synthesis}
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 1.0
set_db -quiet read_qrc_tech_file_rc_corner true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
