######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Sat Sep 12 14:56:10 +07 2026

# This file contains the Genus script for design:picorv32

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path /home/icd1/workspace/RISC-V-PROCESSOR-45nm/lib
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 49 97 52 103} {first_condense 54 167 63 183} {PBS_Generic_Opt-Post 123 170 123.90072200000002 174.67032700000001} {{PBS_Generic-Postgen HBO Optimizations} 1 171 0.0 174.67032700000001} {PBS_TechMap-Start 0 177 0.0 180.173676} {{PBS_TechMap-Premap HBO Optimizations} 1 178 1.0 181.173676} {first_condense 59 237 71 266} {reify 88 325 160 426} {global_incr_map 14 340 16 442} {{PBS_Techmap-Global Mapping} 162 340 160.65377099999984 341.82744699999984} {{PBS_TechMap-Datapath Postmap Operations} 6 346 5.82752499999998 347.6549719999998} {{PBS_TechMap-Postmap HBO Optimizations} 0 346 -0.15774099999998725 347.49723099999983} {{PBS_TechMap-Postmap Clock Gating} 1 347 1.0 348.49723099999983} {{PBS_TechMap-Postmap Cleanup} 1 348 -0.1626449999999977 348.33458599999983} {PBS_Techmap-Post_MBCI 0 348 0.0 348.33458599999983} {incr_opt 16 367 18 471} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path {/home/icd1/workspace/RISC-V-PROCESSOR-45nm /home/icd1/workspace/RISC-V-PROCESSOR-45nm/synthesis}
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 1.0
set_db -quiet read_qrc_tech_file_rc_corner true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
