######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Sat Sep 12 10:18:55 +07 2026

# This file contains the Genus script for design:picorv32

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path /home/icd1/workspace/RISC-V-PROCESSOR-45nm//lib
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 54 156 56 109} {first_condense 55 226 64 190} {PBS_Generic_Opt-Post 129 230 129.75245 181.508293} {{PBS_Generic-Postgen HBO Optimizations} 0 230 0.0 181.508293} {PBS_TechMap-Start 0 237 0.0 187.986716} {{PBS_TechMap-Premap HBO Optimizations} 1 238 0.0 187.986716} {first_condense 64 302 76 278} {reify 94 396 168 447} {global_incr_map 16 412 17 464} {{PBS_Techmap-Global Mapping} 174 412 172.58416599999998 360.570882} {{PBS_TechMap-Datapath Postmap Operations} 6 418 5.830156999999986 366.40103899999997} {{PBS_TechMap-Postmap HBO Optimizations} 0 418 -0.1617289999999798 366.23931} {{PBS_TechMap-Postmap Clock Gating} 1 419 1.0 367.23931} {{PBS_TechMap-Postmap Cleanup} 0 419 0.8388719999999807 368.07818199999997} {PBS_Techmap-Post_MBCI 0 419 0.0 368.07818199999997} {incr_opt 17 440 18 494} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path {/home/icd1/workspace/RISC-V-PROCESSOR-45nm/ /home/icd1/workspace/RISC-V-PROCESSOR-45nm//synthesis}
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 1.0
set_db -quiet read_qrc_tech_file_rc_corner true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
