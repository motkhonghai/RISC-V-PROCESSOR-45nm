######################################################################

# Created by Genus(TM) Synthesis Solution 25.13-s071_1 on Sun Sep 13 15:22:31 +07 2026

# This file contains the Genus script for design:picorv32

######################################################################

set_db -quiet information_level 9
set_db -quiet init_lib_search_path /home/icd1/workspace/RISC-V-PROCESSOR-45nm/lib
set_db -quiet hdl_unconnected_marking_done true
set_db -quiet design_mode_process 60.0
set_db -quiet phys_assume_met_fill 0.0
set_db -quiet map_placed_for_route_early_global false
set_db -quiet phys_use_invs_extraction true
set_db -quiet phys_route_time_out 120.0
set_db -quiet db_units 2000
set_db -quiet capacitance_per_unit_length_mmmc {}
set_db -quiet resistance_per_unit_length_mmmc {}
set_db -quiet runtime_by_stage {{to_generic 51 102 52 104} {first_condense 54 171 62 183} {PBS_Generic_Opt-Post 123 174 124.089207 174.854804} {{PBS_Generic-Postgen HBO Optimizations} 1 175 1.0 175.854804} {PBS_TechMap-Start 0 182 0.0 181.370856} {{PBS_TechMap-Premap HBO Optimizations} 0 182 0.0 181.370856} {first_condense 56 239 66 261} {reify 82 321 129 390} {global_incr_map 20 341 21 411} {{PBS_Techmap-Global Mapping} 159 341 157.66050899999993 339.03136499999994} {{PBS_TechMap-Datapath Postmap Operations} 6 347 5.837415999999962 344.8687809999999} {{PBS_TechMap-Postmap HBO Optimizations} 0 347 -0.15759400000001733 344.7111869999999} {{PBS_TechMap-Postmap Clock Gating} 1 348 1.0 345.7111869999999} {{PBS_TechMap-Postmap Cleanup} 1 349 0.8448650000000271 346.5560519999999} {PBS_Techmap-Post_MBCI 0 349 0.0 346.5560519999999} {incr_opt 20 372 22 445} }
set_db -quiet timing_adjust_tns_of_complex_flops false
set_db -quiet tim_complex_use_dense false
set_db -quiet tim_complex_use_prevs true
set_db -quiet dft_ignore_segment_mode_name false
set_db -quiet dft_lpc_allow_additional_signal_functions false
set_db -quiet dft_use_ungated_clock_for_testpoint true
set_db -quiet tinfo_tstamp_file .rs_icd1.tstamp
set_db -quiet common_preserve_skip_internal true
set_db -quiet exp_within_stylus_db 1
set_db -quiet script_search_path {/home/icd1/workspace/RISC-V-PROCESSOR-45nm /home/icd1/workspace/RISC-V-PROCESSOR-45nm/synthesis}
set_db -quiet syn_map_effort medium
set_db -quiet syn_opt_effort medium
set_db -quiet use_area_from_lef true
set_db -quiet shrink_factor 1.0
set_db -quiet read_qrc_tech_file_rc_corner true
# there is no hdl_instantiated attribute information available
set_db -quiet source_verbose true
