set_clock_latency -source -early -min -rise  -0.0401897 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -early -min -fall  -0.0382355 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -early -max -rise  -0.0401897 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -early -max -fall  -0.0382355 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -min -rise  -0.0401897 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -min -fall  -0.0382355 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -max -rise  -0.0401897 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -max -fall  -0.0382355 [get_ports {clk}] -clock core_clk 
