set_clock_latency -source -early -min -rise  -0.108808 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -early -min -fall  -0.105878 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -early -max -rise  -0.108808 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -early -max -fall  -0.105878 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -min -rise  -0.108808 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -min -fall  -0.105878 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -max -rise  -0.108808 [get_ports {clk}] -clock core_clk 
set_clock_latency -source -late -max -fall  -0.105878 [get_ports {clk}] -clock core_clk 
